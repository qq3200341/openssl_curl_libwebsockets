#include "HelloWorld.hpp"

std::string HelloWorld::helloWorld()
{
  return std::string("Hello World");
}
